#!/usr/bin/env python3

import sys

last_word = None
last_count = 0
word = None

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    # parse the input we got from mapper.py
    word, one = line.split('\t')

    # convert one (a string) to int
    try:
        one = int(one)
    except ValueError:
        # count was not a number, so silently
        # ignore/discard this line
        continue

    # this IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if (last_word and last_word != word):
        # write result to STDOUT
        print(last_word, last_count, sep='\t')
        last_count = 0


    last_word = word
    last_count += one

# do not forget to output the last word!
print(last_word, last_count, sep='\t')