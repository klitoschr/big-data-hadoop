#!/usr/bin/env Rscript

splitIntoFields <- function(line) unlist(strsplit(line,split = '\t'))

con <- file('stdin',open='r')
open(con)

last_key <- NA
sum <- 0
count <- 0

while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  fields <- splitIntoFields(line)
  key <- fields[1]
  sumFromCombiner <- as.numeric(fields[2])
  countFromCombiner <- as.numeric(fields[3])


  if (!is.na(last_key) & last_key != key)
  {

    cat(last_key, '\t', round(sum/count,3),'\n')
    sum <- 0
    count <- 0
  }


  last_key <- key
  sum <- sum + sumFromCombiner
  count <- count + countFromCombiner

}

cat(last_key, round(sum/count,3),'\n', sep='\t')

close(con)



