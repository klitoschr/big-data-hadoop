#! /usr/bin/env Rscript

# reducer.R - Wordcount program in R
# script for Reducer (R-Hadoop integration)

splitIntoFields <- function(line) unlist(strsplit(line, "\t"))

current_movie <- NA
current_count <- 0

con <- file("stdin", open = "r")

while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  fields <- splitIntoFields(line)
  movie <- fields[1]
  count <- fields[2]
  
  count <- try(as.integer(count))
  if (is.na(count)) next
  
  if (!is.na(current_movie) & current_movie==movie)
    current_count <- current_count + count
  else
  {
    if (!is.na(current_movie))
    {
       cat( sprintf('%05d', current_count) , current_movie, "\n", sep="\t")
    }
    current_movie <- movie
    current_count <- count
  }
}

# do not forget to output the last word if needed!
if (current_movie == movie)
  cat( sprintf('%05d', current_count) , current_movie, "\n", sep='\t')


close(con)

