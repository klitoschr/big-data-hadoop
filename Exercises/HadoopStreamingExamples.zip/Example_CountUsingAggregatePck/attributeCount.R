#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)

splitIntoWords <- function(line) unlist(strsplit(line,split = '[\t]'))

con <- file('stdin',open='r')
open(con)

index <- as.integer(args[1])
while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  fields <- splitIntoWords(line)
  cat(paste0("LongValueSum:",fields[index]),'1',sep='\t')
  cat('\n')
}
close(con)

