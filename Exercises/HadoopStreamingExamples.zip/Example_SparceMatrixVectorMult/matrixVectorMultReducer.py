#!/usr/bin/env python3

import sys

(last_i, last_sum) = (None, 0)

for line in sys.stdin:

    (i, val) = line.strip().split("\t")

    if (last_i and last_i != i):
        print( last_i , last_sum , sep='\t')
        last_sum = 0

    last_i = i
    last_sum += float(val)

print( last_i , last_sum , sep='\t')
