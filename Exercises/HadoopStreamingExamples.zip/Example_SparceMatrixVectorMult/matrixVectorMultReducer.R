#!/usr/bin/env Rscript


splitIntoWords <- function(line) unlist(strsplit(line, "\t"))


con <- file('stdin',open='r')

last_sum <- 0
last_i <- NA

while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  fields <- splitIntoWords(line)
  i <- as.numeric(fields[1])
  val <- as.numeric(fields[2])

  if (!is.na(last_i) & last_i != i)
  {
    cat(last_i, last_sum, '\n', sep='\t')
    last_sum <- 0
   }

  last_i <- i
  last_sum <- last_sum + val
}

cat(last_i, last_sum, '\n', sep='\t')

close(con)