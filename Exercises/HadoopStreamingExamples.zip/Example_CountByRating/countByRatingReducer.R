#! /usr/bin/env Rscript

splitIntoFields <- function(line) unlist(strsplit(line, "\t"))

last_key <- NA
last_count <- 0

con <- file("stdin", open = "r")

while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  fields <- splitIntoFields(line)

  key <- fields[1]
  value <- fields[2]

  if (!is.na(last_key) & last_key!=key)
  {
      cat(last_key, last_count, "\n", sep="\t")
      last_count <- 0
  }


  last_key <- key
  last_count <- last_count + as.integer(value)

}

# do not forget to output the last key!
cat(last_key, last_count, "\n", sep="\t")

close(con)

