#!/usr/bin/env python

import sys
index = int(sys.argv[1])

for line in sys.stdin: 
    fields = line.split("\t")
    print("LongValueSum:" + fields[index] + "\t" + "1")
