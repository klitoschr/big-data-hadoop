#!/usr/bin/env Rscript

splitIntoWords <- function(line) unlist(strsplit(line,split = "[,]"))

con <- file('stdin',open='r')
open(con)

last_key <- NA
last_val <- 0
rsum <- 0


while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  fields <- splitIntoWords(line)
  key <- fields[1]
  val <- as.numeric(fields[2])

  if (!is.na(last_key) & last_key == key)
  {
    rsum <- rsum + val * last_val
  }


  last_key <- key
  last_val <- val

}
close(con)

cat('Inner Vector Product is:', rsum,'\n', sep='\t')


