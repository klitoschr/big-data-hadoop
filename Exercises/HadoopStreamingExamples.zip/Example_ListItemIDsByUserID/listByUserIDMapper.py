#!/usr/bin/env python3

import sys

for line in sys.stdin:
    # split line into the four fields
    fields = line.strip().split("\t")
    key = fields[0] #userID
    value = fields[1] #itemID

    print(key, value, sep="\t")
