#! /usr/bin/env Rscript

# reducer.R - Wordcount program in R
# script for Reducer (R-Hadoop integration)

trimWhiteSpace <- function(line) gsub("(^ +)|( +$)", "", line)
splitIntoWords <- function(line) unlist(strsplit(line, "\t"))


last_word <- NA
last_count <- 0

con <- file("stdin", open = "r")

while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  line <- trimWhiteSpace(splitIntoWords(line))
  word <- line[1]
  one <- line[2]

  one <- try(as.integer(one))
  if (is.na(one)) next

  if (!is.na(last_word) & last_word!=word)
     {
      cat(last_word, last_count, "\n", sep="\t")
      last_count <- 0
     }



  last_word <- word
  last_count <- last_count + one
}

# do not forget to output the last word if needed!
cat(last_word, last_count, "\n", sep='\t')

close(con)

