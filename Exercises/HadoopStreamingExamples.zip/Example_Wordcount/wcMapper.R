#! /usr/bin/env Rscript

# mapper.R - Wordcount program in R
# script for Mapper (R-Hadoop integration)

trimWhiteSpace <- function(line) gsub("(^ +)|( +$)", "", line)
removeSpecialSymbols <- function(x) gsub("[.$:;?!,'@]", "", x)
splitIntoWords <- function(line) unlist(strsplit(line, " "))

## **** could wo with a single readLines or in blocks
con <- file("stdin", open = "r")
while (length(line <- readLines(con=con, n = 1, warn = FALSE)) > 0)
{
  words <- trimWhiteSpace(splitIntoWords(line))

  for (word in words)
  {
    w <- removeSpecialSymbols(word)
    cat( tolower(w), 1, sep="\t")
    cat("\n")
  }
}
close(con)