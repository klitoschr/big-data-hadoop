/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


 /* name of your package */
package AverageByAttribute_Pck;


/* Java package for throwing exceptions */
import java.io.IOException;

/* Java package for performing string tokenization, required for the WordCount problem */
import java.util.StringTokenizer;

/* main packages for running Hadoop MapReduce */
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.DoubleWritable;


import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/* packages for extending Configured class */
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;

/* packages for implementing the Tool class and ToolRunner */
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;



public class averageByAttribute extends Configured implements Tool {


  public static class averageByAttrMapper extends Mapper<LongWritable, Text, Text, Text>{

      public void map(LongWritable key, Text value, Context context
                    ) throws IOException, InterruptedException {

              String[] fields = value.toString().split(",",-20);
              String country = fields[4];
              String numClaims = fields[8];

              if (numClaims.length() > 0 && !numClaims.startsWith("\""))
                context.write(new Text(country), new Text(numClaims + ",1"));
      }
    }


  public static class averageByAttrCombiner extends Reducer<Text, Text, Text, Text> {

  public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException{

   double sum = 0;
   int count = 0;

   for (Text val:values)
     {
       String fields[] = val.toString().split(",");
       sum += Double.parseDouble(fields[0]);
       count += Integer.parseInt(fields[1]);
     }

   context.write(key, new Text(sum + "," + count));
  }
}



  public static class averageByAttrReducer extends Reducer<Text,Text,Text,DoubleWritable> {

    public void reduce(Text key, Iterable<Text> values, Context context
                       ) throws IOException, InterruptedException {

     double sum = 0;
     int count=0;

     for (Text val:values)
     {
       String[] fields = val.toString().split(",");
       sum += Double.parseDouble(fields[0]);
       count += Integer.parseInt(fields[1]);
     }

     context.write(key, new DoubleWritable(sum/count));
    }
  }





  public int run(String[] args) throws Exception
   {
        //retrieve default configuration
        Configuration conf = getConf();

          // Create job
        Job job = new Job(conf, "MyJob");
        job.setJarByClass(averageByAttribute.class);
        job.setJar("myAverageByAttribute.jar");
        job.setJobName("AverageByAttributeJob");

         // Setup MapReduce job
        job.setMapperClass(averageByAttrMapper.class);
        job.setCombinerClass(averageByAttrCombiner.class);
        job.setReducerClass(averageByAttrReducer.class);

        // Specify key / value for K2, V2
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        // Specify key / value for K3, V3
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        // Input
        Path in = new Path(args[0]);
        //job.setInputFormatClass(TextInputFormat.class);
        FileInputFormat.setInputPaths(job, in);
        //FileInputFormat.addInputPath(job, new Path(args[0]));

        // Output
        Path out = new Path(args[1]);
        //job.setOutputFormatClass(TextOutputFormat.class);
        FileOutputFormat.setOutputPath(job, out);
        //FileOutputFormat.setOutputPath(job, new Path(args[1]));


        // Execute job and return status
        System.exit(job.waitForCompletion(true) ? 0 : 1);

        return 0;
    }

  public static void main(String[] args) throws Exception
  {
    int res = ToolRunner.run(new Configuration(), new averageByAttribute(), args);

    System.exit(res);
  }


}