#! /usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)

con <- file("stdin", open = "r")
open(con)
while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  randomNum <- round(runif(n = 1,min = 1,max = 100),0)
  if (randomNum <= args[1])
      cat(line,"\n")
}
close(con)


