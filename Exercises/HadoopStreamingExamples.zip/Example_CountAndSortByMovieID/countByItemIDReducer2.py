#!/usr/bin/env python3

import sys

for line in sys.stdin:
    # split line into the two fields
    fields = line.strip().split("\t")
    key = fields[1]
    value = fields[0]

    print(key, value, sep="\t")
