#!/usr/bin/env python3

import sys

# define loop variables
(last_key, last_count) = (None, 0)

for line in sys.stdin:

    # split line into two fields, key and value
    (key, value) = line.strip().split("\t")

    # if last_key has a value and last_key != key we can print
    if (last_key and last_key != key):
        print( last_key , last_count , sep="\t")
        last_count = 0

    # in either case we update the loop variables
    last_key = key
    last_count += int(value)


# dont forget to print the last key!
print( last_key , last_count , sep="\t")
