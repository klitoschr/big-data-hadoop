#!/usr/bin/env python3

import sys

# define loop variables
(last_key, last_string) = (None, "")

for line in sys.stdin:

    # split line into two fields, key and value
    (key, value) = line.strip().split("\t")

    # if last_key has a value and last_key != key we can print
    if (last_key and last_key != key):
        print( last_key , last_string , sep="\t")
        last_string = ""

    # in either case we update the loop variables
    last_key = key
    last_string = last_string + ',' + value


# dont forget to print the last key!
print( last_key , last_count , sep="\t")
