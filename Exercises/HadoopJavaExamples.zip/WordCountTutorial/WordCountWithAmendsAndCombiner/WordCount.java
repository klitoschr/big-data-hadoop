 /**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



 /* name of your package */
package WordCount_Pck;


/* Java package for throwing exceptions */
import java.io.IOException;

/* Java package for performing string tokenization, required for the WordCount problem */
import java.util.StringTokenizer;

/* main packages for running Hadoop MapReduce */
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/* packages for extending Configured class */
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;

/* packages for implementing the Tool class and ToolRunner */
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;



public class WordCount extends Configured implements Tool {

  public static class TokenizerMapper extends Mapper<LongWritable, Text, Text, IntWritable>{

    private final static IntWritable one = new IntWritable(1);
    private Text word = new Text();

    public void map(LongWritable key, Text value, Context context
                    ) throws IOException, InterruptedException {
      StringTokenizer itr = new StringTokenizer(value.toString()," \t\n\r\f,.:;?![]'");   /* 1st addition */
      while (itr.hasMoreTokens()) {
        word.set(itr.nextToken().toLowerCase());                                          /* 2nd addition */

        context.write(word, one);
      }
    }
  }

  public static class IntSumReducer extends Reducer<Text,IntWritable,Text,IntWritable> {
    private IntWritable result = new IntWritable();

    public void reduce(Text key, Iterable<IntWritable> values, Context context
                       ) throws IOException, InterruptedException {
      int sum = 0;
      for (IntWritable val : values) {
        sum += val.get();
      }
      result.set(sum);

      if (sum > 1) context.write(key, result);   /* 3rd addition */
    }
  }


  public int run(String[] args) throws Exception
   {
        //retrieve default configuration
        Configuration conf = getConf();

        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        if (otherArgs.length < 2)
         {
          System.err.println("Usage: wordcount <in> [<in>...] <out>");
          System.exit(2);
         }




        // Create job
        Job job = new Job(conf, "MyJob");
        job.setJarByClass(WordCount.class);
        job.setJar("myWordCount.jar");
        //job.setJobName("WordCountJob");                                                    /* 4th addition */

         // Setup MapReduce job
        job.setMapperClass(TokenizerMapper.class);
        //remember count, max, min, sum are all distributive functions
        job.setCombinerClass(IntSumReducer.class);                                         /* 5th addition */
        job.setReducerClass(IntSumReducer.class);

        // Specify key / value for both mapper and reducer
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        // Input
        for (int i = 0; i < otherArgs.length - 1; ++i)
         {
          FileInputFormat.addInputPath(job, new Path(otherArgs[i]));
         }

        // Output
        FileOutputFormat.setOutputPath(job, new Path(otherArgs[otherArgs.length - 1]));

        // Execute job and return status
        System.exit(job.waitForCompletion(true) ? 0 : 1);

        return 0;
    }

  public static void main(String[] args) throws Exception
  {
    int res = ToolRunner.run(new Configuration(), new WordCount(), args);

    System.exit(res);
  }



}