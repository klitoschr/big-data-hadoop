#!/usr/bin/env Rscript

splitIntoWords <- function(line) unlist(strsplit(line, ","))

con <- file('stdin',open='r')

inputVector = read.table('./vector.txt', sep=',', header=FALSE)
inputVector_idx = inputVector[,1]
inputVector_val = inputVector[,2]


while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  fields <- splitIntoWords(line)
  val_ij <- as.numeric(fields[3])
  i <- fields[1]
  j <- as.numeric(fields[2])

  j_idx <- match(j, inputVector_idx)

  if ( is.na(j_idx) ) next

  cat(i, val_ij * inputVector_val[j_idx] ,sep='\t')
  cat('\n')

}
close(con)