#!/bin/bash

hadoop jar C:\hadoop-2.7.6\share\hadoop\tools\lib\hadoop-streaming-2.7.6.jar
                     -files file:/C:/Users/mbbx6ap3/Desktop/personal/BigData/HadoopMapReduce/HadoopStreaming/Examples/RandomSamplerExample/randomSampler.py
                     -input ./inputData/patentData.txt
                     -output ./outA
                     -mapper "py randomSampler.py 1"


hadoop jar C:\hadoop-2.7.6\share\hadoop\tools\lib\hadoop-streaming-2.7.6.jar \
                     -input ./inputData/patentData.txt \
                     -output ./outA \
                     -file C:\Users\mbbx6ap3\Desktop\personal\BigData\HadoopMapReduce\HadoopStreaming\Examples\RandomSamplerExample\randomSampler.py \
                     -mapper "py randomSampler.py 15"

hadoop jar C:\hadoop-2.7.6\share\hadoop\tools\lib\hadoop-streaming-2.7.6.jar
                     -input ./inputData/patentData.txt
                     -output ./outB
                     -file C:\Users\mbbx6ap3\Desktop\personal\BigData\HadoopMapReduce\HadoopStreaming\Examples\RandomSamplerExample\randomSampler.R
                     -mapper "Rscript randomSampler.R 15"
                     
                     
hadoop jar $HADOOP_HOME\share\hadoop\tools\lib\hadoop-streaming-*.jar
        -input ./hdfs/path/to/randomWords.txt
	-output ./out
        -mapper wcMappper.py
	-reducer wcReducer.py
	-file <local/path/to/wcMapper.py>
	-file <local/path/to/wcReducer.py>
