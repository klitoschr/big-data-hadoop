#!/usr/bin/env Rscript

splitIntoFields <- function(line) unlist(strsplit(line, "\t"))

con <- file('stdin',open='r')

while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  #split line into the four fields
  fields <- splitIntoFields(line)
  key <- fields[3] #rating
  value <- 1

  cat(key, value, sep="\t")
  cat('\n')
  
}

close(con)