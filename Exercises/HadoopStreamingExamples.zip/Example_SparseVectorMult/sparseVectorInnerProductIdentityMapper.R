#!/usr/bin/env Rscript

trimWhiteSpace <- function(line) gsub("(^ +)|( +$)", "", line)

con <- file('stdin',open='r')
open(con)


while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  cat(trimWhiteSpace(line))
  cat('\n')
}  
close(con)
