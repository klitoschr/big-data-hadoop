#!/usr/bin/env python3


import sys

file = open('cachefile','r')
inputVector = [i.strip().split(',') for i in file]
inputVector_idx = [int(i[0]) for i in inputVector]
inputVector_val = [int(i[1]) for i in inputVector]

for line in sys.stdin:
    # split line into two fields, the pair of movies and their similarity
    i,j, val_ij = line.strip().split(',')
    val_ij = float(val_ij)

    # check whether movie j has been rated high from (or preferred by) the user
    try:
        j_idx = inputVector_idx.index(float(j))
    except ValueError:
        # if movie j was not found then skip silently
        continue


    # print to stdout the product component for row/movie i
    print(i, val_ij * inputVector_val[j_idx] ,sep='\t')
