#!/usr/bin/env python3

import sys

for line in sys.stdin:
    # split line into the four fields
    fields = line.strip().split("\t")
    key = fields[1] #itemID
    value = 1

    print(key, value, sep="\t")
