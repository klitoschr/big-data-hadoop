#!/usr/bin/env Rscript

splitIntoWords <- function(line) unlist(strsplit(line, "\t"))

con <- file('stdin',open='r')
while (length(line <- readLines(con, n = 1, warn = FALSE)) > 0)
{
  fields <- splitIntoWords(line)

  key <- fields[2]
  value <- fields[1]

  cat(key, value, sep='\t')
  cat('\n')
}


close(con)